# NexDPI notices and third-party components

NexDPI is a modified build of the Android application ByeDPIAndroid. The upstream Android app is licensed under GNU GPL-3.0 (repository metadata identifies GPL-3.0). This project keeps the Java/Kotlin package namespace needed by the JNI bridge and preserves the upstream license and third-party notices in the checked-out source tree.

Pinned upstream source:
- `https://github.com/dovecoteescapee/ByeDPIAndroid`
- Commit: `43db0955de687d43f9473374dc7c5548eaa55359`

Included upstream submodules at the pinned commit:
- `https://github.com/hufrea/byedpi` — MIT License.
- `https://github.com/heiher/hev-socks5-tunnel` — MIT License.

The Android TV activity, TV layout, NexDPI branding and overlay script in this repository are modifications. These modifications are distributed under GPL-3.0 to remain compatible with the upstream application. The build workflow checks out the exact upstream commit and its recorded submodule revisions before applying the overlay.

This application uses Android's `VpnService` as a local packet-routing interface. It does not connect to a NexDPI-operated VPN server, does not encrypt traffic as a commercial VPN would, and does not hide the public IP address. HTTPS encryption remains provided by the destination website/app in the normal way. A local traffic filter can still observe packet metadata and domain information where the protocol exposes it.
