package io.github.dovecoteescapee.byedpi.activities

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import io.github.dovecoteescapee.byedpi.R
import io.github.dovecoteescapee.byedpi.data.AppStatus
import io.github.dovecoteescapee.byedpi.data.FAILED_BROADCAST
import io.github.dovecoteescapee.byedpi.data.Mode
import io.github.dovecoteescapee.byedpi.data.STARTED_BROADCAST
import io.github.dovecoteescapee.byedpi.data.STOPPED_BROADCAST
import io.github.dovecoteescapee.byedpi.services.ServiceManager
import io.github.dovecoteescapee.byedpi.services.appStatus
import io.github.dovecoteescapee.byedpi.utility.getPreferences
import io.github.dovecoteescapee.byedpi.utility.getStringNotNull
import io.github.dovecoteescapee.byedpi.utility.mode

/** Remote-friendly Android TV entry point. Network engine is the upstream local ByeDPI service. */
class TvMainActivity : AppCompatActivity() {
    private lateinit var statusText: TextView
    private lateinit var statusDetail: TextView
    private lateinit var proxyAddress: TextView
    private lateinit var actionButton: Button
    private var receiverRegistered = false

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            ServiceManager.start(this, Mode.VPN)
        } else {
            Toast.makeText(this, R.string.tv_permission_denied, Toast.LENGTH_LONG).show()
            updateStatus()
        }
    }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                STARTED_BROADCAST, STOPPED_BROADCAST -> updateStatus()
                FAILED_BROADCAST -> {
                    Toast.makeText(this@TvMainActivity, getString(R.string.failed_to_start, "NexDPI"), Toast.LENGTH_LONG).show()
                    updateStatus()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_tv_main)

        statusText = findViewById(R.id.tv_status_text)
        statusDetail = findViewById(R.id.tv_status_detail)
        proxyAddress = findViewById(R.id.tv_proxy_address)
        actionButton = findViewById(R.id.tv_action_button)
        val settingsButton: Button = findViewById(R.id.tv_settings_button)

        actionButton.setOnClickListener { toggleService() }
        settingsButton.setOnClickListener {
            if (appStatus.first == AppStatus.Running) {
                Toast.makeText(this, R.string.tv_settings_running, Toast.LENGTH_LONG).show()
            } else {
                startActivity(Intent(this, SettingsActivity::class.java))
            }
        }

        installFocusFeedback(actionButton)
        installFocusFeedback(settingsButton)

        val filter = IntentFilter().apply {
            addAction(STARTED_BROADCAST)
            addAction(STOPPED_BROADCAST)
            addAction(FAILED_BROADCAST)
        }
        ContextCompat.registerReceiver(
            this,
            stateReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        receiverRegistered = true
        updateStatus()
        actionButton.post { actionButton.requestFocus() }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            unregisterReceiver(stateReceiver)
            receiverRegistered = false
        }
        super.onDestroy()
    }

    private fun toggleService() {
        if (appStatus.first == AppStatus.Running) {
            ServiceManager.stop(this)
            return
        }

        when (getPreferences().mode()) {
            Mode.VPN -> {
                val prepareIntent = VpnService.prepare(this)
                if (prepareIntent != null) vpnPermission.launch(prepareIntent)
                else ServiceManager.start(this, Mode.VPN)
            }
            Mode.Proxy -> ServiceManager.start(this, Mode.Proxy)
        }
    }

    private fun updateStatus() {
        if (!::statusText.isInitialized) return
        val (status, activeMode) = appStatus
        val selectedMode = if (status == AppStatus.Running) activeMode else getPreferences().mode()
        val prefs = getPreferences()
        val ip = prefs.getStringNotNull("byedpi_proxy_ip", "127.0.0.1")
        val port = prefs.getStringNotNull("byedpi_proxy_port", "1080")
        proxyAddress.text = getString(R.string.tv_proxy_address, ip, port)

        if (status == AppStatus.Running) {
            statusText.setText(R.string.tv_status_running)
            actionButton.setText(R.string.tv_disconnect)
        } else {
            statusText.setText(R.string.tv_status_ready)
            actionButton.setText(R.string.tv_connect)
        }
        statusDetail.setText(
            if (selectedMode == Mode.VPN) R.string.tv_mode_vpn else R.string.tv_mode_proxy
        )
    }

    private fun installFocusFeedback(view: View) {
        view.setOnFocusChangeListener { target, focused ->
            target.animate()
                .scaleX(if (focused) 1.04f else 1.0f)
                .scaleY(if (focused) 1.04f else 1.0f)
                .alpha(if (focused) 1.0f else 0.88f)
                .setDuration(120)
                .start()
        }
    }
}
