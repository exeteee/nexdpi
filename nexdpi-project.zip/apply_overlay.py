#!/usr/bin/env python3
"""Apply the NexDPI phone + Android TV overlay to the pinned GPL upstream tree."""
from __future__ import annotations
import argparse
import re
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

ANDROID = "http://schemas.android.com/apk/res/android"
LEANBACK = "android.intent.category.LEANBACK_LAUNCHER"
LAUNCHER = "android.intent.category.LAUNCHER"
MAIN = "android.intent.action.MAIN"
ET.register_namespace("android", ANDROID)
ET.register_namespace("tools", "http://schemas.android.com/tools")


def a(name: str) -> str:
    return f"{{{ANDROID}}}{name}"


def require(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required upstream file is missing: {path}")


def patch_gradle(project: Path) -> None:
    root_settings = project / "settings.gradle.kts"
    require(root_settings)
    settings_text = root_settings.read_text(encoding="utf-8")
    settings_text = settings_text.replace('rootProject.name = "ByeDpi"', 'rootProject.name = "NexDPI"')
    root_settings.write_text(settings_text, encoding="utf-8")

    p = project / "app/build.gradle.kts"
    require(p)
    s = p.read_text(encoding="utf-8")
    if 'applicationId = "io.github.dovecoteescapee.byedpi"' not in s:
        raise RuntimeError("Could not identify upstream applicationId; refusing a blind patch")
    s = s.replace('applicationId = "io.github.dovecoteescapee.byedpi"', 'applicationId = "app.nexdpi.local"', 1)
    s = re.sub(r'versionCode\s*=\s*\d+', 'versionCode = 1', s, count=1)
    s = re.sub(r'versionName\s*=\s*"[^"]+"', 'versionName = "0.1.0"', s, count=1)
    p.write_text(s, encoding="utf-8")


def patch_manifest(project: Path) -> None:
    p = project / "app/src/main/AndroidManifest.xml"
    require(p)
    tree = ET.parse(p)
    root = tree.getroot()
    app = root.find("application")
    if app is None:
        raise RuntimeError("Manifest has no application element")
    app.set(a("label"), "@string/app_name")
    app.set(a("icon"), "@drawable/nexdpi_icon")
    app.set(a("roundIcon"), "@drawable/nexdpi_icon")
    app.set(a("logo"), "@drawable/nexdpi_icon")
    app.set(a("banner"), "@drawable/nexdpi_tv_banner")

    main_found = False
    tv_found = False
    for activity in list(app.findall("activity")):
        name = activity.get(a("name"), "")
        if name == ".activities.MainActivity":
            main_found = True
            for filt in activity.findall("intent-filter"):
                for category in list(filt.findall("category")):
                    if category.get(a("name")) == LEANBACK:
                        filt.remove(category)
        elif name == ".activities.TvMainActivity":
            tv_found = True

    if not main_found:
        raise RuntimeError("Expected MainActivity from upstream was not found")

    if not tv_found:
        tv = ET.SubElement(app, "activity", {
            a("name"): ".activities.TvMainActivity",
            a("exported"): "true",
            a("label"): "@string/app_name",
            a("screenOrientation"): "landscape",
        })
        filt = ET.SubElement(tv, "intent-filter")
        ET.SubElement(filt, "action", {a("name"): MAIN})
        ET.SubElement(filt, "category", {a("name"): "android.intent.category.LEANBACK_LAUNCHER"})

    # The upstream already declares Leanback and optional touchscreen support.
    feature_names = {
        e.get(a("name")) for e in root.findall("uses-feature")
    }
    if "android.software.leanback" not in feature_names:
        ET.SubElement(root, "uses-feature", {a("name"): "android.software.leanback", a("required"): "false"})
    if "android.hardware.touchscreen" not in feature_names:
        ET.SubElement(root, "uses-feature", {a("name"): "android.hardware.touchscreen", a("required"): "false"})

    tree.write(p, encoding="utf-8", xml_declaration=True)


def patch_strings(project: Path) -> None:
    p = project / "app/src/main/res/values/strings.xml"
    require(p)
    s = p.read_text(encoding="utf-8")
    s, n1 = re.subn(r'(<string\s+name="app_name">).*?(</string>)', r'\1NexDPI\2', s, count=1, flags=re.S)
    if n1 != 1:
        raise RuntimeError("Could not patch app_name string")
    s, n2 = re.subn(r'(<string\s+name="notification_title">).*?(</string>)', r'\1NexDPI\2', s, count=1, flags=re.S)
    if n2 != 1:
        raise RuntimeError("Could not patch notification_title string")
    if "tv_subtitle" not in s:
        additions = '''\n    <string name="tv_subtitle">Локальная обработка сетевого трафика</string>\n    <string name="tv_status_ready">Сервис отключён</string>\n    <string name="tv_status_running">Сервис работает</string>\n    <string name="tv_connect">ВКЛЮЧИТЬ</string>\n    <string name="tv_disconnect">ОСТАНОВИТЬ</string>\n    <string name="tv_settings">НАСТРОЙКИ</string>\n    <string name="tv_mode_vpn">Режим локального VPN-интерфейса</string>\n    <string name="tv_mode_proxy">Режим локального SOCKS5-прокси</string>\n    <string name="tv_proxy_address">Локальный адрес прокси: %1$s:%2$s</string>\n    <string name="tv_privacy_note">Трафик обрабатывается на этом устройстве. Сервер разработчика не используется. Это не шифрующий VPN и не меняет ваш внешний IP-адрес.</string>\n    <string name="tv_settings_running">Сначала остановите сервис, затем меняйте настройки</string>\n    <string name="tv_permission_denied">Разрешение VPN не предоставлено</string>\n'''
        s = s.replace("</resources>", additions + "</resources>")
    p.write_text(s, encoding="utf-8")


def copy_overlay(project: Path, overlay: Path) -> None:
    mapping = [
        (overlay / "app/src/main/java/io/github/dovecoteescapee/byedpi/activities/TvMainActivity.kt",
         project / "app/src/main/java/io/github/dovecoteescapee/byedpi/activities/TvMainActivity.kt"),
        (overlay / "app/src/main/res/layout/activity_tv_main.xml",
         project / "app/src/main/res/layout/activity_tv_main.xml"),
        (overlay / "app/src/main/res/color/tv_button_tint.xml",
         project / "app/src/main/res/color/tv_button_tint.xml"),
        (overlay / "app/src/main/res/drawable/nexdpi_icon.xml",
         project / "app/src/main/res/drawable/nexdpi_icon.xml"),
        (overlay / "app/src/main/res/drawable-nodpi/nexdpi_tv_banner.png",
         project / "app/src/main/res/drawable-nodpi/nexdpi_tv_banner.png"),
    ]
    for source, target in mapping:
        require(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

    notice = overlay / "NOTICE.md"
    if notice.exists():
        shutil.copy2(notice, project / "NOTICE-NEXDPI.md")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("upstream", type=Path)
    parser.add_argument("--overlay", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    project = args.upstream.resolve()
    overlay = args.overlay.resolve()
    require(project / "settings.gradle.kts")
    patch_gradle(project)
    patch_manifest(project)
    patch_strings(project)
    copy_overlay(project, overlay)
    print("NexDPI overlay applied successfully")


if __name__ == "__main__":
    main()
